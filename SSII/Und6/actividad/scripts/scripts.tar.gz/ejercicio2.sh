#!/bin/bash

#Ejercicio2

for fichero in *
do
  if [ "$fichero" == "LRSO.dat" ]
  then
     ls LRSO.dat
  fi
done
