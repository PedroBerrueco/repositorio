/**
 * 
 * Unidad 6
 * Ejercicio 6 (Solitario)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */
package pedroberruecound6;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Scanner;

public class E6U6Solitario {

	final static int barajacompleta = 10;

	// M�todo para comprabar si un n�mero es entero y controlar la excepci�n.
	private static boolean isNumber(String s) {
		try {
			Integer.parseInt(s);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		ArrayList<Integer> baraja = new ArrayList<>();
		ArrayDeque<Integer> pilaNueva = new ArrayDeque<>();

	// INICIO - COMPLETAR LA BARAJA Y APILARLA.
		boolean valido;

		do {
			//Pedimos los n n�meros al usuario en forma de cadena, que troceamos ys eparamos en un Array.
			valido = true;
			System.out.print("Introduzca n�meros del 1 al " + barajacompleta + " separados por espacios: ");
			String[] numeros = scanner.nextLine().split(" ");
			//Lo primero que comprobamos es que tengamos todos los espacios del Array completos.
			if (numeros.length != barajacompleta) {
				System.out.println("Debe introducir 10 n�meros");
				valido = false;
			} else {
				//Revisamos cada elemento del Array, comprobamos si es un n�mero, si est� dentro del rango
				//y que no se repita niguno.
				for (String elemento : numeros) {
					if (isNumber(elemento)) { // Comprobamos si es un n�mero.
						int num = Integer.parseInt(elemento);
						if (num > 0 && num <= barajacompleta) { // Comprobamos si est� en el rango.
							if (!baraja.contains(num)) { // Revisamos que no est� repetido.
								baraja.add(num); // S� cumple los requisitos se inserta en la lista baraja.
							} else {
								System.out.println("N�mero repetido.");
								valido = false;
							}
						} else {
							System.out.println("N�mero no v�lido.");
							valido = false;
						}
					} else {
						System.out.println("Caracter extra�o.");
						valido = false;
					}
					if (!valido) { // Si alg�n dato no es v�lido, se vacia la baraja y se repite el bucle.
						baraja.clear();
					}
				}
			}
		} while (!valido); // Mientras valido sea falso, repite el bucle.
		scanner.close();

		/*
		 * Esta parte la he creado asi, pero pienso que el problema est� mal planteado,
		 * si el usuario introduce 10 n�meros en una pila, lo l�gico ser�a que se
		 * apilaran en orden inverso, pero viendo los ejemplos, veo que se apilan en el
		 * mismo orden que se introducen, tomando como primer elemento el primero
		 * escrito. De esta forma me obliga a introducir los n�meros en una lista para
		 * luego incluirlos en una pila en el mismo orden.
		 */
		ArrayDeque<Integer> pila = new ArrayDeque<>(baraja);

	// PROCESO - PARTE EN QUE SE JUEGA
		// He decidido definir las variables antes de la parte donde se usan.
		int contador = 0;
		boolean pilarecargada = false;
		boolean cartacolocada = true;

		do {

			// Recarga la pila original si est� vacia, de lo que tengo pilaNueva.
			if (pila.isEmpty() && (!pilaNueva.isEmpty())) {
				for (Integer elemento : pilaNueva) {
					pila.offerFirst(pilaNueva.poll());
					pilarecargada = true;
				}
			}

			// Saca la primera carta de pila y la pone en pilaNueva
			if (!pila.isEmpty()) {
				pilaNueva.offerFirst(pila.poll());
			}
			// Saca la segunda carta de pila y la pone en pilaNueva
			if (!pila.isEmpty()) {
				pilaNueva.offerFirst(pila.poll());
				cartacolocada = true;
			}

			// Mira carta de PilaNueva
			while (cartacolocada) { //Se repite cada vez que coloque una carta.
				cartacolocada = false;
				if (!pilaNueva.isEmpty()) {
					if (pilaNueva.peekFirst() == (contador + 1)) { // Comprueba si la puede poner
						pilaNueva.poll();
						contador++; //Si la consigue colocar contador suma 1.
						pilarecargada = false; //Al colocarla puede vovler a recargar la pila.
						cartacolocada = true; //Y puede volver a mirar la carta de arriba.
					}
				}
			}
		} while (contador != 10 && !pilarecargada);
		// Repite mientas contador no sea 10 y se haya recargado la pila sin colocar ninguna.

	// SALIDA
		// Podemos tenre dos opciones, que contador haya llegado a 10 o no.
		if (contador == 10) {
			System.out.println("GANA");

		} else {
			System.out.println("PIERDE");
		}

	}
}
