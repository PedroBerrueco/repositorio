/**
 * 
 * Unidad 6
 * Ejercicio 4 (Quien Empieza)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound6;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

//M�todo para comprabar si un n�mero es entero y controlar la excepci�n.
public class E4U6QuienEmpieza {

	private static boolean isNumeric(String cadena) {
		try {
			Integer.parseInt(cadena);
			return true;
		} catch (NumberFormatException nfe) {
			return false;
		}
	}

	static java.util.Scanner in;

	public static void main(String[] args) {

	// INICIO
		Scanner sc = new Scanner(System.in);
		List<Integer> lista = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21,
				22, 23, 24, 25);
		//�Hay alguna forma de crear directamente el ArrayDeque y completarlo sin usar una lista previa?.
		ArrayDeque<Integer> alumnos = new ArrayDeque<>(lista);
		boolean valido = false;
		boolean esnum = false;
		int numero = 0;

		// Comprobacion de entero.
		do {
			System.out.println("Escriba un n�mero de alumno: ");
			String cadena = sc.nextLine();
			// Llama a isNumeric con el valor introducido.
			if (isNumeric(cadena)) {
				numero = Integer.parseInt(cadena);
				esnum = true;
			}
			if (numero > 0 && numero < 26) {
				valido = true;
			}
			//Solo termina el bucle si es n�mero y es v�lido.
		} while (!valido || !esnum);
		sc.close();

	// PROCESO
		//Mientras nos quede m�s de 1 alumno en la lista.
		while (alumnos.size() != 1) {
			//Aunque aqu� no era necesario, he tomado como ejemplo el programa de las bolas de golf de la
			//unidad. As� que saco y metos los n alumnos y desecho al siguiente.
			for (int i = 0; i < numero; i++) {
				alumnos.offer(alumnos.poll());
			}
				alumnos.poll();
		}

	// SALIDA
		//Una vez queda la lista con 1 solo valor, lo muestro.
		System.out.println("Le toca al alumno alumno: " + alumnos.peek());

	}

}
