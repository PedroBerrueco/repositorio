/**
 * 
 * Unidad 6
 * Ejercicio 2 (Teclado escacharrado)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound6;

import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;

public class E2U6Teclado {

	public static void main(String[] args) {
	
	//INICIO
		Scanner sc = new Scanner(System.in);
		
		//Creamos dos listas, una para guardar lo que introduzca el usuario:
		LinkedList <Character> Lista = new LinkedList<>();
		//Otra para guardar las modificaciones del teclaso escacharrado.
		LinkedList <Character> Lista2 = new LinkedList<>();
		ListIterator<Character> li = Lista2.listIterator();
		String cadena;
		char caracter;
		
		System.out.println("Introduce una cadena: ");
		cadena = sc.next();
		sc.close();
		//Guardamos cada caracter por separado en la lista con un bucle FOR.
		for (int i = 0; i < cadena.length(); i++) {
			caracter = cadena.charAt(i);
			Lista.add(caracter);
		}
		
	//PROCESO
		//Con ayuda de un iterador, le indicamos que debe guardar en la segunda lista
		//seg�n el car�cter que se encuentre.
	for (Character elemento : Lista) {
		if (elemento != '3' && elemento != '-' && elemento != '*' && elemento != '+') {
			li.add(elemento);
		}
		if (elemento == '3') {
			if(li.hasNext()) {
				li.next();
				li.remove();
			}
		}
		if (elemento == '-') {
			while(li.hasPrevious())
				li.previous();
		}
		if (elemento == '+') {
			while(li.hasNext())
				li.next();
		}
		if (elemento == '*') {
			if(li.hasNext()) {
				li.next();
			}
		}
	}
		
	//SALIDA
		//Para que el resultado se muestre como en el ejemplo no vale con imprimir la
		// la lista, por eso utilizo el bucle para que imprima cada caracter.
		for (Character character : Lista2) {
			System.out.print(character);
			
		}
	}
}