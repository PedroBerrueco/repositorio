package ejercicio2und11;

public class Test {

	public static void main(String[] args) {

		//Se crean los distintos objetos  que luego formaran parte de un ordenador
		CPU cpu = new CPU(8, 3200, 2, "Intel");
		Pantalla pantalla = new Pantalla(24, true, "LCD", 400);
		Teclado teclado = new Teclado(6, 84, "USB", true);
		Raton raton = new Raton(2, 3, "USB", false);

		CPU cpu1 = new CPU(4, 1600, 1, "AMD");
		Pantalla pantalla1 = new Pantalla(17, false, "TFT", 200);
		Teclado teclado1 = new Teclado(5, 80, "USB", false);
		Raton raton1 = new Raton(1, 2, "PS2", false);

		//Se crean los objetos ordenadores
		Ordenador windows = new Ordenador("Windows", cpu, pantalla, raton, teclado);
		Ordenador linux = new Ordenador("Linux", cpu1, pantalla1, raton1, teclado1);
		
		//Probamos los m�todos de las clases no principales.
		cpu.overclock(3200);
		pantalla.encender();
		teclado1.desconectar();
		raton1.dblclick();
		
		// Se crea un Array de PCs que es el par�metro que espera el M�todo ImprimirOrdenador
		Ordenador[] listaPCs = { windows, linux };
		Ordenador.imprimirOrdenador(listaPCs);
		

	}

}