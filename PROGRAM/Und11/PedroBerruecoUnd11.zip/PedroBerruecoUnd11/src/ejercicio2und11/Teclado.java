package ejercicio2und11;

public class Teclado { 
    
	
    private int tama�o; 
    private int numeroDeTeclas; 
    private String conexi�n; 
    private boolean retroiluminado; 
    
    /**
     * CONSTRUCTOR
     * @param tama�o en pulgadas
     * @param numeroDeTeclas total del teclado
     * @param conexi�n Tipo de conexi�n (USB/PS2)
     * @param retroiluminado �Tiene retroiluminaci�n?
     */
    public Teclado(int tama�o, int numeroDeTeclas, String conexi�n, boolean retroiluminado) { 
        this.tama�o = tama�o; 
        this.numeroDeTeclas = numeroDeTeclas; 
        this.conexi�n = conexi�n; 
        this.retroiluminado = retroiluminado; 
    } 
    
    /**
     * Metodo para conectar el teclado al ordenador
     */
    public void conectar() { 
        System.out.println("El teclado se ha conectado correctamente"); 
    } 
    
    /**
     * Metodo para desconectar el teclado del ordenador.
     */
    public void desconectar() { 
        this.conexi�n = null;
    	System.out.println("El teclado se ha desconectado correctamente"); 
    }

	@Override
	public String toString() {
		return "Teclado [tama�o=" + tama�o + ", numeroDeTeclas=" + numeroDeTeclas + ", conexi�n=" + conexi�n
				+ ", retroiluminado=" + retroiluminado + "]";
	} 
    
    
} 
