package ejercicio2und11;

public class Ordenador {
	private String os;
	private CPU cpu;
	private Pantalla pantalla;
	private Raton raton;
	private Teclado teclado;

	// Constructor
	public Ordenador(String os, CPU cpu, Pantalla pantalla, Raton raton, Teclado teclado) {
		this.os = os;
		this.cpu = cpu;
		this.pantalla = pantalla;
		this.raton = raton;
		this.teclado = teclado;
	}

	// GETTERS
	public String getOS() {
		return this.os;
	}

	public CPU getCPU() {
		return this.cpu;
	}

	public Pantalla getPantalla() {
		return this.pantalla;
	}

	public Raton getRaton() {
		return this.raton;
	}

	public Teclado getTeclado() {
		return this.teclado;
	}

	// M�todo para imprimir los datos de los ordenadores
	public static void imprimirOrdenador(Ordenador[] listaPCs) {
		for (Ordenador ordenador : listaPCs) {
			System.out.println("Ordenador "+ ordenador.getOS()+ ":");
			System.out.println("CPU: " + ordenador.getCPU());
			System.out.println("Pantalla: " + ordenador.getPantalla());
			System.out.println("Raton: " + ordenador.getRaton());
			System.out.println("Teclado: " + ordenador.getTeclado());
		}
	}
}
