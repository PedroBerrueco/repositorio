package ejercicio2und11;

public class Raton { 
    
    private int tama�o; 
    private int botones; 
    private String conexi�n; 
    private boolean ilumina; 
    
    /**
     * CONSTRUCTOR
     * @param tama�o pulgadas del rat�n
     * @param botones N�mero de botones del mouse
     * @param conexi�n Tipo de conexion (USB/PS2)
     * @param ilumina �Se ilumina el diodo LED?
     */
    public Raton(int tama�o, int botones, String conexi�n, boolean ilumina) { 
        this.tama�o = tama�o; 
        this.botones = botones; 
        this.conexi�n = conexi�n; 
        this.ilumina = ilumina; 
    } 
    
    /**
     * Metodo cuando se hace un click con el rat�n 
     */
    public void click() { 
    	this.ilumina = true;
        System.out.println("Se ha hecho click con el rat�n"); 
    } 
    
    /**
     * Metodo cuando se hace doble click con el rat�n
     */
    public void dblclick() { 
    	this.ilumina = true;
        System.out.println("Se ha hecho doble click con el rat�n"); 
    }

	@Override
	public String toString() {
		return "Raton [tama�o=" + tama�o + ", botones=" + botones + ", conexi�n=" + conexi�n + ", inal�mbrico="
				+ ilumina + "]";
	} 
    
    
}