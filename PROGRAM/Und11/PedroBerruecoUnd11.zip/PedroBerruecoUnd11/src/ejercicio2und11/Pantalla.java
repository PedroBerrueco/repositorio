package ejercicio2und11;

public class Pantalla { 
    
    private int tama�o; 
    private boolean encendida;
    private String modelo;
    private long precio;
    
   /**
    * CONSTRUCTOR
    * @param tama�o en pulgadas
    * @param resoluci�n 
    * @param modelo
    * @param precio
    */
    public Pantalla(int tama�o, boolean encendida, String modelo, long precio) {
		this.tama�o = tama�o;
		this.encendida = encendida;
		this.modelo = modelo;
		this.precio = precio;
	}
    
    /**
     * M�todo para encender la pantalla pone el atributo encendida a true.
     */
	public void encender() { 
        this.encendida = true;
		System.out.println("Pantalla encendida"); 
    } 
    
	/**
     * M�todo para apagar la pantalla pone el atributo encendida a false.
     */
    public void apagar() { 
    	this.encendida = false;
        System.out.println("Pantalla apagada"); 
    }

	@Override
	public String toString() {
		return "Pantalla [tama�o=" + tama�o + ", encendida=" + encendida + ", modelo=" + modelo + ", precio=" + precio
				+ "]";
	} 
    
}
