package ejercicio2und11;

public class CPU { 
    
    private int nucleos;
	private int velocidad; 
    private int memoria; 
    private String marca; 
    
  
    /**
     * CONSTRUCTOR 
     * @param nucleos del procesador.
     * @param velocidad del bus del micro.
     * @param memoria cach�.
     * @param frecuencia de reloj del micro.
     */
    public CPU(int nucleos, int velocidad, int memoria, String marca) {
		this.nucleos = nucleos;
		this.velocidad = velocidad;
		this.memoria = memoria;
		this.marca = marca;
	}
    
    /**
     * Este metodo realiza un overclok de la CPU duplicando la velocidad.
     * @param velocidad pasamos la velocidad del bus de la CPU al m�todo.
     */
	public void overclock(int velocidad) { 
       this.velocidad = (velocidad * 2);
       System.out.println("CPU overcloked, velocidad ahora es " + this.velocidad);
    } 
    
	/**
     * Este metodo realiza un underclok de la CPU dividiendo la velocidad.
     * @param velocidad pasamos la velocidad del bus de la CPU al m�todo.
     */
    public void underclock(int velocidad) { 
    	this.velocidad = (velocidad / 2);
        System.out.println("CPU undercloked, velocidad ahora es " + this.velocidad);
    }

	@Override
	public String toString() {
		return "CPU [nucleos=" + nucleos + ", velocidad=" + velocidad + ", memoria=" + memoria + ", marca=" + marca
				+ "]";
	} 
    
    
} 
