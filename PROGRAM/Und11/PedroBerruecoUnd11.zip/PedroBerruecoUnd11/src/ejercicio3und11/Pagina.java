package ejercicio3und11;

public class Pagina {

	private String contenido;
	private int numero;
	
	/**
	 * CONSTRUCTOR
	 * @param contenido D�nde ir�n los parrafos de p�gina
	 * @param numero de p�gina.
	 */
	public Pagina(String contenido, int numero) {
		this.contenido = contenido;
		this.numero = numero;
	}
	
	/**
	 * GETTERS Y SETTERS
	 */
	public String getContenido() {
		return contenido;
	}

	public int getNumero() {
		return numero;
	}
	
	public void setContenido(String contenido) {
		this.contenido = contenido;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	
}