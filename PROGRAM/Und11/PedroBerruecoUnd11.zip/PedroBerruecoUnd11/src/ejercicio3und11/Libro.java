package ejercicio3und11;

import java.util.ArrayList;
import java.util.List;

public class Libro {
    private String titulo;
    private String isbn;
    private String autor;
    private int anoPublicacion;
    private List<Pagina> paginas;
    
    /**
     * CONSTRUCTOR
     * @param titulo del libro
     * @param isbn o c�digo �nico del libro
     * @param autor del libro
     * @param anoPublicacion A�o de publicaci�n del libro
     */
    public Libro(String titulo, String isbn, String autor, int anoPublicacion) {
        this.titulo = titulo;
        this.isbn = isbn;
        this.autor = autor;
        this.anoPublicacion = anoPublicacion;
        this.paginas = new ArrayList<>();
    }
    
    /**
     * Metodo para a�adir p�ginas al libro, 
     * @param pagina es un objeto de la clase @see Pagina
     */
    public void addPagina(Pagina pagina) {
        paginas.add(pagina);
    }
    
    /**
     * Metodo para imprimir el libro y cada p�gina.
     */
    public void imprimirLibro() {
        System.out.println("Libro [titulo=" + titulo + ", isbn=" + isbn + ", autor=" + autor + ", anoPublicacion=" + anoPublicacion + "]");
        for (Pagina pagina : paginas) {
            System.out.println("P�gina " + pagina.getNumero() + " - " + pagina.getContenido() + " ]");
        }
    }
}