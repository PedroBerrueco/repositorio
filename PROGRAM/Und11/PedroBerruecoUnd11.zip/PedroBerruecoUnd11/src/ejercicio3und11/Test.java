package ejercicio3und11;

public class Test {
    public static void main(String[] args) {
        Libro libro = new Libro("Un regalo diferente", "9788496388093", "Marta Azcona", 2005);
        libro.addPagina(new Pagina("El d�a de su cumplea�os, Marcel invit� a Trist�n a merendar en su casa...", 1));
        libro.addPagina(new Pagina("Marcel abri� el regalo y ...", 2));
        libro.addPagina(new Pagina("Es un trozo de tela que me sobr� de las cortinas...", 3));
        libro.addPagina(new Pagina("Marcel invit� a su amigo a t� y pastelitos de nata", 4));
        libro.addPagina(new Pagina("Y como no quer�an ensuciarse...", 5));
        libro.imprimirLibro();
    }
}