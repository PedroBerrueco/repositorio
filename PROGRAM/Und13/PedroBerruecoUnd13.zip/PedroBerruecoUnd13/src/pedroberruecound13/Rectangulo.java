package pedroberruecound13;

/**
 * @author paberrueco
 */

//Rectángulo implementa a Figura
public class Rectangulo implements Figura {

	protected double base;
	protected double altura;
	protected char caracter;
	
	
	

	public Rectangulo(double base, double altura, char caracter) {
		this.base = base;
		this.altura = altura;
		this.caracter = caracter;
	}

	@Override // Implementa el nombre de la figura para la clase Rectangulo.
	public String Nombre() {
		String nombre = "Rectangulo";
		return nombre;
	}

	@Override  //Usamos una matriz para dibujar la figura.
	public void Dibujar() {
	    char[][] matriz = new char[(int) altura][(int) base];
	    for (int i = 0; i < matriz.length; i++) {
	        for (int j = 0; j < matriz[0].length; j++) {
	            matriz[i][j] = caracter;
	            System.out.print(matriz[i][j]);
	        }
	       System.out.println();
	    }
	}
	@Override  //Implementamos el área de la figura para la clase rectángulo.
	public double Area() {
		double area = base * altura;
		return area;
	}
	

	@Override 
	public char getCaracter() {
		return caracter;
	}

	@Override
	public void SetCaracter(char caracter) {
		this.caracter = caracter;
		
	}

	@Override 
	public String toString() {
		return "Rectangulo [base=" + base + ", altura=" + altura + "]";
	}

	

}
