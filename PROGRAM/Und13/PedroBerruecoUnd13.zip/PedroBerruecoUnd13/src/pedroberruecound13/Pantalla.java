package pedroberruecound13;
import java.util.ArrayList;

/**
 * 
 * @author paberrueco
 *
 */

//Aquí se van a almacenar las figuras 
public class Pantalla {
    private ArrayList<Figura> figuras;

    //CONSTRUCTOR
    public Pantalla() { 
        figuras = new ArrayList<Figura>();
    }
    
    //Añadimos las figuras que se vayan creando
    public void anadeFigura(Figura figura) {
        figuras.add(figura);
    }
    
    //Modificamos el carácter con el que se dibujan las figuras
    public void modificaFigura(char caracter) {
        for (Figura figura : figuras) {
            figura.SetCaracter(caracter);
        }
    }
    
    //Mostramos las figuras del ArrayList
    public void listaFiguras() {
        System.out.println("Figuras en pantalla:");
        for (Figura figura : figuras) {
            System.out.println("- " + figura.Nombre());
        }
    }
    
    //Calculamos el area de cada pantalla
    public void areaPantalla() {
        for (Figura figura : figuras) {
            System.out.print(figura.toString() + " ");
        	System.out.println("Area: " + figura.Area());
        }
    }

    //Dibujamos las fiuras almacenaas en el ArrayList
    public void muestraPantalla() {
        System.out.println("Pantalla:");
        for (Figura figura : figuras) {
            figura.Dibujar();
        }
    }
}

