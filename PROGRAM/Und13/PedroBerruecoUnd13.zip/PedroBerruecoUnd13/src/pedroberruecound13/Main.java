/**
 * @author paberrueco
 * version 1.0
 */
package pedroberruecound13;

import java.util.Scanner;

/**
 * 
 * @class Main - Clase principal dónde empieza el programa.
 *
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Pantalla dibujos = new Pantalla(); 
        String opcion = " ";
        char opcionchar = 'x';
        char caracterchar = '*';
        
       //El programa se repite mientras el usuario no pulse f
        do {
        System.out.println("Seleccione una opción: [a-f] ");
        System.out.println("a - Añadir una figura");
        System.out.println("b - Modificar una figura");
        System.out.println("c - Mostrar la pantalla");
        System.out.println("d - Área de la pantalla");
        System.out.println("e - Listar Figuras");
        System.out.println("f - Salir");
        opcion = sc.next();
 
        // Comprobamos si la opción introducida es una letra entre la "a" y la "f".
        if (Utilidades.isAlpha(opcion)) {
        	 opcionchar = opcion.charAt(0);
        	
        	//Switch case con cada caso.
        	switch (opcionchar) {
			case 'a': // La opción "a" implementará la figura.
				System.out.println("¿Rectángulo (r) o Triángulo (t)? ");
				opcion = sc.next();
				if (opcion.equals("r")) {
					System.out.println("Indica la base: ");
					String base = sc.next();
					System.out.println("Indica la altura: ");
					String altura = sc.next();
					System.out.println("Indica el caracter: ");
					String caracter = sc.next();
					if (Utilidades.isInteger(base) && Utilidades.isInteger(altura)) {
						caracterchar = caracter.charAt(0);
						int numbase = Integer.parseInt(base);
						int numaltura = Integer.parseInt(altura);
						Rectangulo r = new Rectangulo(numbase, numaltura, caracterchar);
						dibujos.anadeFigura(r);
					}else {
						System.out.println("Opción no válida, vuelva a intentarlo");
					}
					
				} else if (opcion.equals("t")) {
					System.out.println("Indica el lado: ");
					String lado = sc.next();
					System.out.println("Indica el caracter: ");
					String caracter = sc.next();
					if (Utilidades.isInteger(lado)) {
						caracterchar = caracter.charAt(0);
						int numlado = Integer.parseInt(lado);
						Triangulo t = new Triangulo(numlado, caracterchar);
						dibujos.anadeFigura(t);
					}else {
						System.out.println("Opción no válida, vuelva a intentarlo");
					}
						
				} else {
					System.out.println("Opción no válida, vuelva a intentarlo");
				}
				break;
			
			case 'b':
				System.out.println("Elige nuevo caracter: ");
				String caracter = sc.next();
				caracterchar = caracter.charAt(0);
				dibujos.modificaFigura(caracterchar);
				break;
				
			case 'c':
				dibujos.muestraPantalla();
				break;
				
			case 'd':
				dibujos.areaPantalla();
				break;
			
			case 'e':	
				dibujos.listaFiguras();
				break;
				
			case 'f':	
				System.out.println("ADIOS");
				break;
				
			default:
				break;
			}
        	
        }else {
        	System.out.println("Opción no válida, vuelva a intentarlo");
        }
        
        } while (opcionchar != 'f');
        
        
    }
}
