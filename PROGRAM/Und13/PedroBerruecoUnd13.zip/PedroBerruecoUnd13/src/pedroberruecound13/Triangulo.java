package pedroberruecound13;

/**
 * @author paberrueco
 */

//Triángulo implementa a Figura
public class Triangulo implements Figura {
	
	protected double lado;
	protected String tipo;
	protected char caracter;
	
	public Triangulo(double lado, char caracter) {
	    this.lado = lado;
	}
	
	@Override // Implementa el nombre de la figura para la clase Triangulo.
	public String Nombre() {
		String nombre = "Triangulo";
		return nombre;
	}

	@Override //Usamos una matriz para dibujar la figura.
	public void Dibujar() { 
		char[][] matriz = new char[(int)lado][(int)lado];
	    for (int i = 0; i < lado; i++) {
	        for (int j = 0; j < lado; j++) {
	            if (j <= i) {
	                matriz[i][j] = caracter;
	            } else {
	                matriz[i][j] = ' ';
	            }
	        }
	    }
	    for (int i = 0; i < lado; i++) {
	        for (int j = 0; j < lado; j++) {
	            System.out.print(matriz[i][j] + " ");
	        }
	        System.out.println();
	    }
	}
	@Override //Implementamos el área de la figura para la clase Triangulo.
	public double Area() {
		double area = (lado*lado) /2;
		return area;
	}
	@Override
	public void SetCaracter(char caracter) {
		this.caracter = caracter;
	}
	@Override
	public char getCaracter() {
	    return caracter;
	}

	@Override
	public String toString() {
		return "Triangulo [lado=" + lado + "]";
	}



}
