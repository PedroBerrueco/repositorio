package pedroberruecound13;

/**
 * 
 * @author paberrueco
 *
 */

//Interface pura, con metodos totalmente vacios.
public interface Figura {
	
	String Nombre(); //Devuelve el nombre de la figura	
	void Dibujar(); //Pinta en la pantalla la figura	
	double Area(); //Calcula el Area de la figura		
	char getCaracter(); //Muestra el carácter para dibujar la figura.
	void SetCaracter(char caracter);

}
