/**
 * 
 * Unidad 7
 * Ejercicio 4 (Repetidor)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound7;

/*

import java.util.ArrayList;
import java.util.Scanner;

public class E4U7Repetidores {

	public static void main(String[] args) {
		
		 
		Scanner sc = new Scanner(System.in);
		ArrayList<String> alumnosRepetidores = new ArrayList<>();
		 
		// Leemos los nombres de los alumnos del a�o pasado.
		System.out.print("Introduce los nombres de los alumnos del a�o pasado: ");
		String[] alumnosPasados = sc.nextLine().split(" ");
		 
		// Leemos los nombres de los alumnos del a�o actual.
		System.out.print("Introduce los nombres de los alumnos del a�o actual: ");
		String[] alumnosActuales = sc.nextLine().split(" ");
		 
		 
		        
		 
		        for (int i = 0; i < alumnosPasados.length; i++) {
		            for (int j = 0; j < alumnosActuales.length; j++) {
		                if (alumnosPasados[i].equals(alumnosActuales[j])) {
		                    alumnosRepetidores.add(alumnosPasados[i]);
		                }
		            }
		        }
		 
		        System.out.println("Los alumnos repetidores son: ");
		        for (String alumno : alumnosRepetidores) {
		            System.out.print(alumno + " ");
		        }
		    }
		}
*/

import java.util.LinkedHashSet;
import java.util.Scanner;

public class E4U7Repetidores {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
	//INICIO
		// Creamos una colecci�n vacia de alumnos repetidores. Como lista para mantener
		// la posici�n.
		LinkedHashSet<String> alumnosRepetidores = new LinkedHashSet<>();

		// Leemos los nombres de los alumnos del a�o pasado.
		System.out.print("Introduce los nombres de los alumnos del a�o pasado: ");
		String[] alumnosPasados = sc.nextLine().split(" ");

		// Leemos los nombres de los alumnos del a�o actual.
		System.out.print("Introduce los nombres de los alumnos del a�o actual: ");
		String[] alumnosActuales = sc.nextLine().split(" ");

	//PROCESO
		// Controlamos may�sculas y mn�sculas del a�o pasado
		for (int i = 0; i < alumnosPasados.length; i++) {
			alumnosPasados[i] = alumnosPasados[i].substring(0, 1).toUpperCase()
					+ alumnosPasados[i].substring(1).toLowerCase();
		}

		// controlamos may�sculas y min�sculas del a�o actual
		for (int i = 0; i < alumnosActuales.length; i++) {
			alumnosActuales[i] = alumnosActuales[i].substring(0, 1).toUpperCase()
					+ alumnosActuales[i].substring(1).toLowerCase();
		}

		// Con un for completamos Set comparando arrays de ambos cursos.
		for (int i = 0; i < alumnosPasados.length; i++) {
			for (int j = 0; j < alumnosActuales.length; j++) {
				if (alumnosPasados[i].equals(alumnosActuales[j])) {
					alumnosRepetidores.add(alumnosPasados[i]);
				}
			}
		}
	//SALIDA
		// He creado un foreach para que el resultado saliera como en el ejemplo
		// Podr�a haberlo imprimido directamente aunque hubiera salido distinto.
		System.out.println("Los alumnos repetidores son: ");
		for (String alumno : alumnosRepetidores) {
			System.out.print(alumno + " ");
		}
	}
}
