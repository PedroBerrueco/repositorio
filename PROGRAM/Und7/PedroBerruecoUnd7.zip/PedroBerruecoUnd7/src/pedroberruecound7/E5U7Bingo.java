/**
 * 
 * Unidad 7
 * Ejercicio 5 (Bingo)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound7;

import java.util.Scanner;
import java.util.TreeSet;

public class E5U7Bingo {

	final static int numerosbol = 5;

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		TreeSet<Integer> boleto = new TreeSet<>();
	//INICIO	
		int num = 0;
		boolean bingo = false;

		// Pedimos al usuario los n�meros del boleto
		System.out.print("Introduzca " + numerosbol + " n�meros ");
		for (int i = 0; i < numerosbol; i++) {
			boolean esInt = false;
			//cada n�mero lo verificamos.
			while (!esInt) {
				if (sc.hasNextInt()) {
					boleto.add(sc.nextInt());
					esInt = true;
				} else {
					System.out.println("Introduzca n�meros enteros");
					sc.nextLine();
				}
			}
		}
	//PROCESO + SALIDA
		
		//Aqu� hubiera utilizado el metodo try-catch para validar enteros que use en la Und6
		//pero como has dicho que no debemos usarlo he tenido que enfarrar un poco el c�digo.
		
		while (!bingo) {
			boolean isInt = false;
			while (!isInt) {
				if (sc.hasNextInt()) {
					num = sc.nextInt();// Leemos el numero que sale del bombo
					bingo = true;
					isInt = true;
				} else {
					System.out.println("Introduzca un numero entero");
					sc.nextLine();
				}
			}
			 // Buscamos si el numero esta en el boleto
			if (boleto.contains(num)) {
				boleto.remove(num); // Si esta, lo eliminamos del Set.
			}

			// Comprobamos si todos los numeros han sido eliminados
			if (!boleto.isEmpty()) {
				bingo = false;
			}

			// Si todos los numeros han sido eliminados, cantamos BINGO
			if (bingo) {
				System.out.println("BINGO");
			}
		}
	}

}