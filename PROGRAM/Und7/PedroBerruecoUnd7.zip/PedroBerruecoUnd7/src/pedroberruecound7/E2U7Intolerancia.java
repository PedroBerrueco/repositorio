/**
 * 
 * Unidad 7
 * Ejercicio 2 (Intolerancia)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound7;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;

public class E2U7Intolerancia {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
	
	//INICIO
		//Creo dos colecciones de alimentos una para  ayer y otra para los de hoy.
		HashSet<String> ayer = new HashSet<>();
		HashSet<String> hoy = new HashSet<>();
		String alimentos;
		
		//Pido al usuario que introduzca una cadena de alimentos.
		System.out.print("Comida de ayer (riesgo): ");
		alimentos = sc.nextLine();
		String[] alimenriesgo = alimentos.split(" ");
		//Utilizo un Array de String para separar los alimentos por espacio.
		ayer.addAll (Arrays.asList (alimenriesgo));
		
		
		//idem comida de ayer.
		System.out.print("Comida de hoy (segura): ");
		alimentos = sc.nextLine();
		String[] alimensano = alimentos.split(" ");
		hoy.addAll (Arrays.asList (alimensano));
	
	//PROCESO	
		//Retiro los alimentos de la colecci�n ayer que coincidan con la colecci�n hoy.
		ayer.removeAll(hoy); 
		
	//SALIDA
		System.out.println(ayer);
		

	}

}
