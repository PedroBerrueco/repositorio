package pedroberruecound14;

/**
 * 
 * @author paberrueco
 * @version 1.0
 */

//Clase E3U14
public class E3U14 {
	//Defino el parámetros como constante al principio de la clase.
	static private int parametro = 0;

	/**
	 * @param num "El parámetro que le pasamos al método, será un entero y
	 *            representará el divisor."
	 * @return Devolverá el resultado de la división.
	 */
	public int incertidumbre(int num) {
		int res = 0; // Inicializamos variable para el resultado
		// Intentamos dividir 100 entre el parámetro
		try {
			res = 100 / num;
			// En caso de generar una excepción la capturamos.
		} catch (Exception e) {
			/*
			 * Pero el programa no continua porque le hemos pasado un return. El programa
			 * devolverá un -1.
			 */
			return -1;
			/*
			 * En caso de no haber excepción finally se ejecutará y cambiará el valor que
			 * tuviera "res" tras la operación por -2.
			 */
		} finally {
			res = -2;
		}
		// Si llegamos a este return siempre se devolverá -2 a causa del finally.
		return res;

		/*
		 * En resumen, este método devolverá -1 en caso de saltar una excepción, si por
		 * ejemplo pasamos el parametro 0 como divisor. Y devolverá -2 en caso de poder
		 * realizar la división.
		 */
	}

	/**
	 * Método Main.
	 */
	public static void main(String[] args) {
		// Instanciamos un objeto de la clase para poder llamar a sus métodos.
		E3U14 ejemplo = new E3U14();
		// Aquí se muestra el mensaje que devuelva el método incertidumbre y le pasamos
		// el parametro que hará de divisor.
		System.out.println(ejemplo.incertidumbre(parametro));
	}
}
