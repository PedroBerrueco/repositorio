package pedroberruecound14;

import java.util.Scanner;

public class E2U14 {

	public int SumNum(String texto) {
		int resultado = 0;
		for (int i = 0; i < texto.length(); i++) {
			// He metido el try-catch dentro del for para que capture excepción por cada
			// letra de la cadena.
			try {
				resultado += Integer.parseInt(texto.substring(i, i + 1));
			} catch (Exception e) {
			}

		}
		return resultado;
	}

	public static void main(String[] args) {

		E2U14 ejemplo = new E2U14();
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduzca varios números seguidos");
		int suma = ejemplo.SumNum(sc.nextLine());
		System.out.println("La suma de los dígitos es: " + suma);

	}
}
