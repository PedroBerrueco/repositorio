package pedroberruecound14;

import java.util.ArrayList;
import java.util.Scanner;


//CLASE EXCEPCION PROPIA.
	class ExPropia extends Exception {

		// CONSTRUCTOR
		public ExPropia(String mensaje) {
			super(mensaje);
		}

		@Override
		// METODO TO_STRING.
		public String toString() {
			return ("Se ha producido una Excepcion Propia: " +
					this.getClass().getName() + "\n" + "Con el mensaje: " + this.getMessage());
		}

	}

public class E5U14 {

	// METODO PARA QUITAR LETRAS DE LA CADENA
	public ArrayList<Integer> noLetras(String multiplos) {
		ArrayList<Integer> lista = new ArrayList<>();
		for (int i = 0; i < multiplos.length(); i++) {
			try {
				int numero = Integer.parseInt(multiplos.substring(i, i + 1));
	            if (lista.size() < 5) {
	                lista.add(numero);
	            }
			} catch (Exception e) {
			}
		}
		return lista;

	}

	//METODO PARA EVITAR CEROS
	public static void noCeros(ArrayList<Integer> lista) throws ExPropia{
	    for (int num : lista) {
	      if (num == 0) {
	        throw new ExPropia("No valen CEROS");
	      }
	    }
	  }
	
	public static void main(String[] args) {
		
		E5U14 multi = new E5U14();
		Scanner sc = new Scanner(System.in);
		ArrayList<Integer> lista2 = new ArrayList<>();
		
		System.out.println("Introduzca 5 numeros (NO CEROS): ");
		
		lista2 =(multi.noLetras(sc.nextLine()));
		try {
			multi.noCeros(lista2);
			int multiplica = 1;
			for (int cada: lista2) {
				multiplica *= cada;
			} 
			System.out.println("Resultado: " + multiplica);
			
		} catch (ExPropia e) {
			 e.printStackTrace();
		}
		
	}

}
