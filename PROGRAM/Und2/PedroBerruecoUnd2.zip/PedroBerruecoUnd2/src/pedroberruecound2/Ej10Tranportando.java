/**
 * 
 * Unidad 2
 * Ejercicio 10 (Transportando agua)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound2;

import java.util.Scanner;

public class Ej10Tranportando {

	public static void main(String[] args) {

	// INICIO
		Scanner in = new Scanner(System.in);

		// Declaramos una variable de tipo entero para cada tama�o de botella.
		int garrafa5;
		int botella2;
		int botella05;

	// PROCESO + SALIDA
		// Solicitamos al usuario el valor total de litros y guardamos dicho valor en
		// una variable llamada "litros".
		System.out.print("Cantidad de litros de agua (1-1000) ");
		int litros = in.nextInt();

		// Dividimos el total de litros entre 5 y as� obtenemos las garrafas de 5 litros
		// en las que podemos meter esos litros.
		garrafa5 = (litros / 5);
		// Utilizamos Print sin el ln para que nos imprima todo en la misma l�nea.
		System.out.print(garrafa5 + " Botellas de 5 litros, ");
		// Generamos una nueva variable para guardar los litros restante de la divisi�n
		// entre 5 "restolitros1".
		int restolitros1 = (litros % 5);

		// Dividimos el resto de litros entre 2 y as� obtenemos las botellas de 2 litros
		// en las que podemos meter estos litros.
		botella2 = (restolitros1 / 2);
		System.out.print(botella2 + " Botellas de 2 litros, ");
		// Generamos una nueva variable para guardar los litros restante de la divisi�n
		// entre 2 "restolitros2".
		int restolitros2 = (restolitros1 % 2);

		// Dividimos el resto de litros entre 0,5 y as� obtenemos las botellas de 1/2
		// litro en las que podemos meter los �ltimos litros.
		botella05 = (int) (restolitros2 / 0.5);
		System.out.print(botella05 + " Botellas de 1/2 litro.");
	}
}
