/**
 * 
 * Unidad 2
 * Ejercicio 6 (En Secuencia)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound2;

import java.util.Scanner;

public class Ej6Secuencia {

	public static void main(String[] arg) {

	// INICIO
		Scanner in = new Scanner(System.in);
		
		// Pedimos al usuario que introduzca la cantidad de numeros a escribir y guardamos dicho valor en la variable "cantidad".
		System.out.print("Introduzca la cantidad de n�meros: ");
		int cantidad = in.nextInt();
		
		//Declaramos dos variables de tipo booleano para cubrir una posible serie ascendente o descendente.
		boolean asc = false;
		boolean desc = false;
		
		/* 
		 * En mi caso, he sido incapaz de encontrar un m�todo que me permitiera guardar un n�mero "N" de valores con lo visto en las Unidades
		 * as� que busque una forma en internet.
		 * Encontr� los Arrays o Arreglos y tuve que aprender a utilizarlos para poder incluirlos en el ejercicio, por lo que no he 
		 * "usado la ventaja de conocer alternativas que se veran m�s adelante". Al rev�s, me llev� muchas horas sacar este ejercicio.
		 */
		
		//Declaro un objeto de tipo entero llamado "array" y le doy el valor de la variable cantidad.
		int array[] = new int[cantidad];
		
		
		
	// PROCESO
		/*
		 * Con un for: 
		 * Inicio un indice a 0, mientras este indice tenga un valor menor que el valor del objeto array, 
		 * incrementa el valor del indice en uno para el siguiente ciclo.
		 */
		for (int i = 0; i < array.length; i++) {
			//Guarda el valor introducido por el usuario en cada ciclo del for.
			array[i] = in.nextInt();
		}

		/*
		 * Ahora que tenemos el valor de cada uno de los N n�meros que ha escrito el usuario, vamos a usar otro for para compararlos.
		 */
		for (int i = 0; i < array.length - 1; i++) {
			/*
			 * Si el valor del array en cualquiera de los ciclos es mayor que el valor del array en el ciclo siguiente,
			 * entenderemos que la serie es descendente y pondremos la variable "desc" a true. 
			 */
			if (array[i] > array[i + 1]) {
				desc = true;
			}
			/*
			 * Si el valor del array en cualquiera de los ciclos es menor que el valor del array en el ciclo siguiente,
			 * entenderemos que la serie es ascendente y ponedremos la variable "asc" a true. 
			 */
			if (array[i] < array[i + 1]) {
				asc = true;
			}
		}
		
	// SALIDA
		
		// Si hemos encontrados patrones ascendentes, pero no descendentes, muestra por pantalla el texto "Ascendente".
		if (asc == true && desc == false) {
			System.out.println("Ascendente");
		}
		// Si hemos encontrados patrones descendentes, pero no ascendentes, muestra por pantalla el texto "Descendente".
		if (asc == false && desc == true) {
			System.out.println("Descendente");
		}
		// Si hemos encontrados ambos patrones quiere decir que la serie no sigue un orden, mostrar� "Desordenada".
		if (asc == true && desc == true) {
			System.out.println("Desordenada");
		}
	}

}
