/**
 * 
 * Unidad 2
 * Ejercicio 8 (Pr�stamo)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound2;

import java.util.Scanner;

public class Ej8Prestamo {

	public static void main(String[] args) {

	// INICIO
		Scanner in = new Scanner(System.in);
		// Declaramos las variables de tipo double y las inicializamos para que tomen dos decimales ya que son n�meros para operaciones econ�micas. 
		double prestamo = 0.00d;
		double recorte = 0.00d;
		double resta = 0.00d;
		
		// Solicitamos el importe inicial y lo guardamos en la variable "prestamo".
		System.out.print("Introduja el importe del pr�stamo: ");
			prestamo = in.nextDouble();
		
		
	// PROCESO
				do {
					// El usuario introducira el monto a descontar del prestamo
					recorte = in.nextDouble();
					// Esa cifra la sumamos a la variable resta.
					resta = resta + recorte;
					//Si la resta del prestamos menos lo descontado es mayor que cero, mostrar� el resto faltante.
					if (prestamo - resta >0) {
					System.out.println(prestamo - resta);
					}
				// El bucle se repetir� mientras  la resta del prestamo menos lo descontado sea mayor que cero.
				} while (prestamo - resta > 0); 
	// SALIDA
				System.out.println("Has saldado el pr�stamo");
				in. close();
		}

	}


