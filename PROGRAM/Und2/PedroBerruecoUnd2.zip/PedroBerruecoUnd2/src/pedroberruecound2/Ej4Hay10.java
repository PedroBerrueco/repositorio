/**
 * 
 * Unidad 2
 * Ejercicio 4 (Hay 10)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound2;

import java.util.Scanner;

public class Ej4Hay10 {

	public static void main(String[] args) {

	// INICIO
		Scanner in = new Scanner(System.in);
		
		/*
		 * Declaramos dos variables, "numero" que tomara el valor que indique el usuario
		 * y "otrodiez" que aumentar� 1 cada vez que encuentre un 10.
		 */
		int numero;
		int otrodiez = 0;
		

	// PROCESO
		do {
			// Pide el numero, guarda su valor y comprueba si es 10.
			System.out.print("Introduzca un n�mero [0-10]: ");
			numero = in.nextInt();
			if (numero == 10) {
				otrodiez++; // Si es 10, incrementa el valor de "otrodiez".
			}
		} while (numero != -1); // Se repetir� el bucle mientras el n�emero introducido sea distinto de -1. 
	
	// SALIDA
		/*
		 * Si la variable "otrodiez" tiene un valor mayor que cero, quiere decir que 
		 * en alguno de los bucles ha encontrado un 10 y por lo tanto debe imprimir "SI".
		 *
		 *En caso contrario imprimir� "NO"
		 */
		if (otrodiez > 0) {
			System.out.println("S�");
		} else {
			System.out.println("NO");
		}

	}
}
