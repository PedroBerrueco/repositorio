/**
 * 
 * Unidad 2
 * Ejercicio 2 (D�a de la semana)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound2;

import java.util.Scanner;

public class Ej2DiadelaSemana {

	public static void main(String[] args) {
		
	// INICIO
		Scanner sc = new Scanner(System.in);
		// Pedimos al usuario que introduzca un n�mero del 1 al 7 y guardamos dicho valor en la variable "teclado".
		System.out.print("Introduzca un n�mero del 1 al 7: ");
		int teclado = sc.nextInt();
		// Declaramos la variable de tipo String "diasem" y la inicializamos con texto vacio.
		String diasem = "";
		// Buena pr�ctica, cerrar la transmisi�n de Scanner para liberar recursos.
		sc.close();

	// PROCESO
		// Seg�n el dato que tome la variable "teclado" le damos un valor de texto a la variable "diasem" utilizando Switch.
		switch (teclado) {
		case 1:
			diasem = "Lunes";
			break;
		case 2:
			diasem = "Martes";
			break;
		case 3:
			diasem = "Mi�rcoles";
			break;
		case 4:
			diasem = "Jueves";
			break;
		case 5:
			diasem = "Viernes";
			break;
		case 6:
			diasem = "S�bado";
			break;
		case 7:
			diasem = "Domingo";
			break;
		default:
			diasem = "N�mero incorrecto";
		}
	
	// SALIDA
		// Imprimimos el valor que haya tomado la variable "diasem".
		System.out.println(diasem);

	}

}
