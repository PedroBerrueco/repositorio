/**
 * 
 * Unidad 3
 * Ejercicio 2 (�Cu�nto queda?)
 * 
 * @version 2.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound3_v2;

import java.util.Arrays;
import java.util.Scanner;

/*
 * CORRECI�N.
 * Olvid� comprobar que los n�meros introducidos estuvieran entre 1 y 50.
 * He aprovechado la correci�n del ejercicio para trabajar la creaci�n y llamada a objetos.
 * La idea era llamar a un objeto para rellenar el array y realizar el resto del ejercicio en el m�todo main,
 * pero seg�n iban surgiendo problemas se ha ido liando todo.
 * Al menos he conseguido que funcione, aunque es un concepto que aun no domino. 
 */

class MiClase {

	Scanner in = new Scanner(System.in);

	public int[] completarray(int[] totalkm) {
		// Por cada vuelta del bucle consulta al usuario los km de la etapa.
		for (int i = 0; i < totalkm.length; i++) {
			System.out.print("Escribe el n�mero de km de la etapa " + (i + 1) + " para continuar: ");
			totalkm[i] = in.nextInt();
		}

		return totalkm;
	}

	public int kmsumados(int[] totalkm) {
		int suma = 0;
		// recorremos array totalkm para sumar sus valores.
		for (int i = 0; i < totalkm.length; i++) {
			suma += totalkm[i];
		}
		return suma;
	}

	public boolean menos50(int[] totalkm) {
		boolean resultado = true;

		// recorremos array totalkm para saber si hay n�meros mayores de 50.
		for (int i = 0; i < totalkm.length; i++) {
			if ((totalkm[i]) < 1 || (totalkm[i] > 50)) {
				resultado = false;
			}
		}

		return resultado;

	}

}

class E2U3Cuantoqueda {

	public static void main(String[] args) {
		// INICIO
		int totalkm[] = new int[5]; // KM de cada etapa.
		int[] restokm = new int[totalkm.length]; // Km restantes por etapa.
		int suma2 = 0; // Total de Km.

		// Creo objeto completarray que llama al m�todo completarray.
		MiClase completarray = new MiClase();
		completarray.completarray(totalkm);

		// Creo objeto kmsumados que llama al m�todo kmsumados.
		MiClase kmsumados = new MiClase();
		suma2 = kmsumados.kmsumados(totalkm);

		// Creo objeto menos50.
		MiClase menos50 = new MiClase();

		// PROCESO
		// Mientras el valor que devuelva menos50 sea false, vuelve a completar el array
		// y recalcula suma2.
		while (menos50.menos50(totalkm) == false) {
			System.out.println("Numeros erroneos, vuelva a empezar");
			completarray.completarray(totalkm);
			suma2 = kmsumados.kmsumados(totalkm);
		}

		// Por cada bucle rellenamos una posici�n del array y vamos restando
		// los km de cada etapa para que nos quede resto.
		for (int i = 0; i < totalkm.length; i++) {
			restokm[i] = suma2;
			suma2 -= totalkm[i];
		}
		// SALIDA
		// Usamos el envoltorio de Arrays "tostring".
		System.out.println(Arrays.toString(restokm));
	}
}
