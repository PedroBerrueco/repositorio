/**
 * 
 * Unidad 3
 * Ejercicio 4 (�Hay repetidos?)
 * 
 * @version 2.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound3_v2;

import java.util.Arrays;
import java.util.Scanner;

public class E4U3Hayrepetidos {

	public static void main(String[] args) {
	// INICIO
		Scanner sc = new Scanner(System.in);
		int array[] = new int[6];
		// CORRECCI�N_ variable auxiliar tomar� el valor m�nimo posible.
		int aux = Integer.MIN_VALUE;
		//CORRECCION Nueva variable.
		int comprueba = 0;
		boolean repetido = false;

	// PROCESO
		// CORRECCI�N 
		//Pedimos al usuario los valores del array. Incluimos comprobacion
		//de datos de entrada
		for (int i = 0; i < array.length; i++) {
			do {
				System.out.print("Numero " + (i + 1) + ": ");
				comprueba = sc.nextInt();
			} while ((comprueba < 0) || (comprueba > 100));
			array[i] = comprueba;
		}

		// Ordenacion del array para aunar valores iguales.
		Arrays.sort(array);

		/*
		 * Comparar cada elemento del array con el anterior, si est� repetido pondr� la
		 * boolean a true. Si no aux tomar� valor de array[i]
		 */
		for (int i = 0; i < array.length; i++) {
			if (aux == array[i]) {
				repetido = true;
			} else {
				aux = array[i];
			}

		}
		// SALIDA
		// imprime un mensaje en funcion de la condicion booleana.
		if (repetido == true) {
			System.out.println("S�");
		} else {
			System.out.println("NO");
		}
	}
}
