/**
 * 
 * Unidad 3
 * Ejercicio 10 (Elegid al delegado)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound3_v2;

import java.util.Scanner;

public class E10U3Delegado {

	public static void main(String[] args) {

	// INICIO	
		Scanner sc = new Scanner(System.in);
		// Array para pedir el voto a cada alumno con una longitud de 30 posiciones.
		int[] array = new int[30];
		// variable numero iniciada en 1, ya que cuando sea 0 saldr� del bucle.
		int numero = 1;
		
		/* 
		 * Como este ejercicio es algo complejo, tuve que ir inventando variables
		 * y arrays sobre la marcha para irlos usando en los distintos FOR.
		 * En esta ocasi�n los he dejado en el proceso porque tenerlos ah� me ayuda a 
		 * explicar que papel tienen en la siguiente funci�n.
		 */

	// PROCESO	
		// Pide el voto de cada uno de los 30 alumnos.
		for (int i = 0; i < array.length; i++) {
			// Si la respuesta es 0, deja de pedir n�meros.
			if (numero != 0) {
				System.out.print("Alumno " + (i + 1) + ": ");
				array[i] = sc.nextInt();
				numero = array[i];
			}

		}

		// Nuevo array para guardar la suma de votos de cada alumno por cada una de las
		// respuestas.
		int contador = 0;
		int[] votos = new int[30];

		// Metemos un ciclo dentro de otro, por cada vuelta del primer ciclo busca una
		// respuesta igual en el resto de posiciones del array.
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++)
				// Si el valor de la posici�n es 0 no lo suma ya que todos los valores desde el
				// primer cero hasta la pocision 30 ser�n 0 y si los sumamos, siempre ser�a 0 el
				// ganador.
				if ((array[i] == array[j]) && (array[i] != 0))
					contador++;
			votos[i] = contador;
			contador = 0;
		}

		// Vamos a almacenar el mayor n�mero de votos y numero del alumno con m�s votos.
		int mayor = 0;
		int alumayor = 0;
		boolean empate = false;

		for (int i = 0; i < votos.length; i++) {
			// Si el n�mero mayor de votos es m�s peque�o que la siguiente suma de votos de
			// un alumno, este �ltimo ser� el nuevo n�mero mayor.
			if (mayor < votos[i]) {
				mayor = votos[i];
				alumayor = array[i];
				// Siempre que encontremos esta condici�n la variable empate ser� falsa.
				empate = false;
			}

			// Si hay dos numeros de votos iguales y los numeros de alumno con esta cifra de
			// votos son distintos la variable empate pase a ser cierta.
			if ((alumayor != array[i]) && (mayor == votos[i])) {
				empate = true;
			}

		}
	// SALIDA
		// Si empate es igual a true debe mostrar el texto "empate" en caso contrario
		// debe mostrar el n�mero del ganador.
		if (empate == true) {
			System.out.println("empate");

		} else {
			System.out.println(alumayor);
		}
	}

}
