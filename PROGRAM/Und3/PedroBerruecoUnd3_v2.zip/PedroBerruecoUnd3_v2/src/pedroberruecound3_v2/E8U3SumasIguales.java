/**
 * 
 * Unidad 3
 * Ejercicio 8 (Sumas iguales)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound3_v2;

import java.util.Arrays;
import java.util.Scanner;

public class E8U3SumasIguales {

	public static void main(String[] args) {

	// INICIO
		Scanner sc = new Scanner(System.in);
		// Array con los n�meros facilitados por el usuario
		int array[] = new int[5];
		// Array para almacenar los valores de "array" en posici�n invertida.
		int invertido[] = new int[5];
		// variable para ir sumando valores encontrados en el array.
		int suma = 0;
		// variable para ir sumando valores encontrados en el array invertido.
		int sumainv = 0;
		// variable de tipo booleano para almacenar si hay coincidencia de sumas o no.
		boolean esigual = false;
	
	// PROCESO
		// Pedimos al usuario los valores del array.
		for (int i = 0; i < array.length; i++) {
			System.out.print("Cantidad " + (i + 1) + ": ");
			array[i] = sc.nextInt();
		}
		// For para invertir los n�meros del array anterior
		for (int i = 0; i < invertido.length; i++) {
			/*
			 * El valor de cada posici�n del vector invertido ser� igual al valor del array
			 * original en la posici�n de su longitud menos uno y menos el indice actual.
			 */
			invertido[i] = array[(array.length - 1) - i];
		}

		// Un for para sumar los n�meros que vamos tomando desde el inicio.
		for (int i = 0; i < array.length; i++) {
			suma += array[i];
			sumainv = 0;
			/*
			 * Un for para sumar los n�meros que vamos tomando desde el final hasta el largo
			 * del array invertido menos uno menos el indice del for anterior.(los que
			 * faltan por coger).
			 */
			for (int j = 0; j < (invertido.length - 1) - i; j++) {
				sumainv += invertido[j];
				/*
				 * Si encontramos alguna suma igual entre lo que tenemos y lo que nos queda,
				 * ponemos el booleano a true.
				 */
				if (suma == sumainv) {
					esigual = true;

				}

			}
		}
	// SALIDA
		// imprimimos si o no seg�n el valor del booleano.
		if (esigual == true) {
			System.out.println("S�");
		} else {
			System.out.println("NO");
		}
	}
}