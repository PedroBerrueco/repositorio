/**
 * 
 * Unidad 3
 * Ejercicio 6 (Mayor secuencia de 3)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound3;

import java.util.Scanner;

public class E6U3MayorSecuenciade3 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
	// INICIO
		// Array para solicitar los valores al usuario
		int array[] = new int[9];
		// variables que usaremos para sumar y almacenar los valores usados en la suma.
		int suma = 0;
		int elmas = 0;
		int elmasant = 0;
		int elmassig = 0;
	
	//PROCESO
		// Pido los n�meros al usuario
		for (int i = 0; i < array.length; i++) {
			System.out.print("Numero " + (i + 1) + ": ");
			array[i] = sc.nextInt();
		}
		/*
		 * Por cada posici�n del Array sumar� el valor del �ndice actual, �ndice
		 * anterior e �ndice posterior. Si la nueva suma es mayor que la variable suma,
		 * actualizo mis par�metros con estos datos.
		 */
		for (int i = 0; i < array.length; i++) {
			// Condici�n especial solo para cuando estamos en la primera posici�n (Evitar
			// out of bounds.)
			if (i == 0) {
				suma = (array[i] + array[i + 1]);
				elmasant = 0;
				elmas = array[i];
				elmassig = array[i + 1];
			}
			// Condici�n especial solo para cuando estamos en la ultima posici�n (Evitar out
			// of bounds.)
			if (i == array.length - 1) {
				if (suma < (array[i - 2] + array[i - 1] + array[i])) {
					suma = (array[i - 2] + array[i - 1] + array[i]);
					elmasant = array[i - 2];
					elmas = array[i - 1];
					elmassig = array[i];
				}
			}
			// condicion para el resto de casos
			if ((i != 0) && (i != (array.length - 1))) {
				if (suma < (array[i - 1] + array[i] + array[i + 1])) {
					suma = (array[i - 1] + array[i] + array[i + 1]);
					elmasant = array[i - 1];
					elmas = array[i];
					elmassig = array[i + 1];
				}
			}

		}
	// SALIDA
		// Imprimimos los valores que han quedado en las variables que han provocado la
		// m�xima suma.
		System.out.println(elmasant + "-" + elmas + "-" + elmassig);

	}

}
