/**
 * 
 * Unidad 3
 * Ejercicio 4 (�Hay repetidos?)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound3;

import java.util.Arrays;
import java.util.Scanner;

public class E4U3Hayrepetidos {

	public static void main(String[] args) {
	// INICIO	
		Scanner sc = new Scanner(System.in);
		// Array para solicitar al usuario los n�meros a introducir.
		int array[] = new int[6];
		// variable auxiliar tomar� el primer valor del array.
		int aux = array[0];
		// Esta variable de tipo boolean la usaremos para almacenar la condici�n de
		// repetici�n (verdadera o falsa)
		boolean repetido = false;
	
	// PROCESO
		// Pedimos al usuario los valores del array.
		for (int i = 0; i < array.length; i++) {
			System.out.print("Numero " + (i + 1) + ": ");
			array[i] = sc.nextInt();

		}

		// Ordenacion del array para que si hay dos indices iguales aparezca uno detr�s
		// del otro.
		Arrays.sort(array);

		/*
		 * Comparar cada elemento del array con el anterior, si est� repetido pondr� la
		 * variable repetido a true. En caso no estar repetido dara el valor del �ndice
		 * actual a la variable aux y continuar� con el siguiente bucle
		 */
		for (int j = 0; j < array.length; j++) {
			if (aux == array[j]) {
				repetido = true;
			} else {
				aux = array[j];
			}

		}
	//SALIDA
		// imprime un mensaje en funcion de la condicion booleana.
		if (repetido == true) {
			System.out.println("S�");
		} else {
			System.out.println("NO");
		}
	}
}
