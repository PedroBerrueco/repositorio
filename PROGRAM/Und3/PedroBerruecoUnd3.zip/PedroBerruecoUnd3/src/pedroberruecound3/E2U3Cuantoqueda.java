/**
 * 
 * Unidad 3
 * Ejercicio 2 (�Cu�nto queda?)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound3;

import java.util.Arrays;
import java.util.Scanner;

public class E2U3Cuantoqueda {

	public static void main(String[] args) {
	// INICIO
		Scanner in = new Scanner(System.in);
		// En este Array almacenaremos los km de cada etapa.
		int totalkm[] = new int[5];
		// En este array almacenaremos los km restantes tras cada etapa
		int[] restokm = new int[totalkm.length];
		// variable que almacena el total de km.
		int suma = 0;

	// PROCESO
		// Por cada vuelta del bucle consulta al usuario los km de la etapa, los suma a
		// la variable suma.
		for (int i = 0; i < totalkm.length; i++) {
			System.out.print("Escribe el n�mero de km de la etapa " + (i + 1) + " para continuar: ");
			totalkm[i] = in.nextInt();
			suma += totalkm[i];
		}

		// Nuevo For, por cada bucle rellenamos una posici�n del array y vamos restando
		// los km de cada etapa para que nos quede resto.
		for (int i = 0; i < totalkm.length; i++) {
			restokm[i] = suma;
			suma -= totalkm[i];
		}
	// SALIDA
		// Usamos el envoltorio de Arrays "tostring" para que imprima los valores del
		// array.
		System.out.println(Arrays.toString(restokm));
	}
}