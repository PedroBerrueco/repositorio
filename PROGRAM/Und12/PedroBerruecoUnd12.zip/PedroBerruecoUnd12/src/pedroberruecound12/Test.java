package pedroberruecound12;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EmpleadoProduccion currito = new EmpleadoProduccion("Mariano", 12345678, 23, "Noche");
		EmpleadoDistribucion currela = new EmpleadoDistribucion("Paco", 87654321, 22, "Entrev�as");
		
		// USAMOS UN METODO DE LA CLASE EMPLEADO PRODUCCION Y OTRO DE LA CLASE ASALARIADO
		System.out.println("Dame los datos del currito: " + currito.getNombre() + " " + currito.getTurno());
		System.out.println(currito.toString());
		
		// USAMOS UN METODO DE LA CLASE EMPLEADO DISTRIBUCION Y OTRO DE LA CLASE ASALARIADO
		System.out.println("Dame los datos del currela: " + currela.getNombre() + " " + currela.getZona());
		System.out.println(currela.toString());
		
		
		
	}

}
