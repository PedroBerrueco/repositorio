package pedroberruecound12;

public class EmpleadoDistribucion extends Asalariado {
	private String zona;
	
	/**
	 * CONSTRUCTOR
	 * @param nombre Atributo heredado nombre del Asalariado @See Asalariado
	 * @param dni	Atributo heredado dni del Asalariado @See Asalariado
	 * @param vacaciones Atributo heredado vacaciones del Asalariado @See Asalariado
	 * @param zona Centro donde trabaja.
	 */
	public EmpleadoDistribucion(String nombre, long dni, int vacaciones, String zona) {
		super(nombre, dni, vacaciones);
		this.zona = zona;
	}
	
	/**
	 * Setter
	 * @return zona 
	 */
	public String getZona() {
		return zona;
	}
	
	/**
	 * Getter
	 * @param zona
	 */
	public void setZona(String zona) {
		this.zona = zona;
	}

	@Override
	/**
	 * Utilizamos tanto atributos propios como heredados
	 */
	public String toString() {
		return "EmpleadoDistribucion [zona=" + zona + ", Nombre=" + nombre + ", dni=" + dni + ", vacaciones=" + vacaciones + "]";
	}



}
