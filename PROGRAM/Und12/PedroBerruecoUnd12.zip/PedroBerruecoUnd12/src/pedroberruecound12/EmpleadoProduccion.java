package pedroberruecound12;

public class EmpleadoProduccion extends Asalariado {
		private String turno;
		
		/**
		 * CONSTRUCTOR
	 * @param nombre Atributo heredado nombre del Asalariado @See Asalariado
	 * @param dni	Atributo heredado dni del Asalariado @See Asalariado
	 * @param vacaciones Atributo heredado vacaciones del Asalariado @See Asalariado
	 * @param turno Horario en el que trabaja (Ma�ana, Tarde o Noche)
		 */
		public EmpleadoProduccion(String nombre, long dni, int vacaciones, String turno) {
			super(nombre, dni, vacaciones);
			this.turno = turno;
		}
		
		/**
		 * Getter
		 * @return turno
		 */
		public String getTurno() {
			return turno;
		}
		
		/**
		 * Setter
		 * @param turno
		 */
		public void setTurno(String turno) {
			this.turno = turno;
		}

		@Override
		/**
		 * Utilizamos tanto atributos propios como heredados
		 */
		public String toString() {
			return "EmpleadoProduccion [turno=" + turno + ", Nombre=" + nombre + ", dni=" + dni + ", vacaciones=" + vacaciones + "]";
		}
		
		
}
