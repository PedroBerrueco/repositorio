/**
 * Unidad 9
 * Ejercicio 4 (Cuenta Corriente).
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound9;

class CuentaCorriente {
	public String saldo; //Atributo String
	
	/**
	 * Constructor pone saldo a 0.
	 */
	public CuentaCorriente() {
				saldo = "0";
	}
	/**
	 * @return Devuelve el saldo en la cuenta
	 */
	public int getSaldo() { 
		Integer saldoint = Integer.parseInt(saldo);	
		return saldoint;
		
	}
	
	/**
	 * M�todo para ingresar dinero en la cuenta
	 * @param x cantidad a ingresar.
	 */
	public void imposicion (int x) {
		Integer saldoint = Integer.parseInt(saldo);
		saldoint += x;
		saldo = saldoint.toString();
	}
	
	/**
	 * M�todo para sacar dinero de la cuenta.
	 * @param x cantidad a retirar
	 */
	public void reintegro (int x) {
		//Sacar dinero int
		Integer saldoint = Integer.parseInt(saldo);
		saldoint -= x;
		saldo = saldoint.toString();
	}
	
	
}

public class E4U9CuentaCorriente {

	public static void main(String[] args) {
		// Se crea objeto cc de la clase CuentaCorriente
		CuentaCorriente cc = new CuentaCorriente(); 
		cc.imposicion(200); //Se llama al metodo imposicion
		cc.reintegro(300); // Se llama al m�todo reintegro
		System.out.println(cc.getSaldo()); //Se llama al m�todo getSaldo.

	}

}
