/**
 * Unidad 9
 * Ejercicio 5 (Coche).
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound9;

class Coche {
	public int ruedas;
	public int velocidad;
	
	/**
	 * CONSTRUCTOR
	 */
	public Coche() { 
		ruedas = 4;
		velocidad = 0;
	}
	
	
	public int getRuedas() {
		return ruedas;
	}

	public void setRuedas(int ruedas) {
		this.ruedas = ruedas;
	}  

	public int getVelocidad() { 
		return velocidad;
	}

	/**
	 * 
	 * @param velocidad Modifica la velocidad del veh�culo
	 */
	public void setVelocidad(int velocidad) { 
		this.velocidad = velocidad;
	}
	
	/**
	 * 
	 * @param cantidad de Velocidad que incrementa el coche.
	 */
	public void acelerar (int cantidad) {
			//Acelerar sin superar 120
			if (velocidad + cantidad <= 120) {
				velocidad += cantidad;
			}
	}
	
	/**
	 * 
	 * @param cantidad cantidad de Velocidad que decrementa el coche.
	 */
	public void frenar (int cantidad) {
		//Frenar sin llegar a negativo
		if (velocidad - cantidad >= 0) {
			velocidad -= cantidad;
		}
		
	}
	
	/**
	 * M�todo toString autogenerado.
	 */
	@Override
	public String toString() {
		return "Coche [ruedas=" + ruedas + ", velocidad=" + velocidad + "]";
	}
	
	
}

public class E5U9Coche {

	public static void main(String[] args) {

		//Se crean objetos mini y porche de la clase coche
		Coche mini = new Coche(); 
		Coche porche = new Coche();
		// Se asigna velocidad a mini y se acelera con metodo acelerar.
		mini.setVelocidad(70);
		mini.acelerar(20);
		mini.acelerar(40); //No cumple condici�n del m�todo, asi que no suma.
		// Se asigna velocidad a porche y se frena con metodo frenar.
		porche.setVelocidad(120);
		porche.frenar(90);
		porche.frenar(40); //No cumple condici�n del m�todo, asi que no resta.
		System.out.println("Mini " + mini);
		System.out.println("Porche "+ porche);
	}

}
