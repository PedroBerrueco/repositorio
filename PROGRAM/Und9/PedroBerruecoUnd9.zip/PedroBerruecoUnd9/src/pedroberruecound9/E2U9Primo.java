/**
 * Unidad 9
 * Ejercicio 2 (Primo).
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound9;

 class Primo {
		public int num;
		/**
		 * Constructor
		 * @param num Valor del parametro con el que crearemos el objeto
		 */
		public Primo(int num) {
			this.num = num;
		}
		
		public void setValue(int n) {
			//cambia valos de num para ello se le debe pasar un valor
			num = n;
		}
		
		public Integer getValue() {
			//devuelve valor de num
			return num;
		}
		
		/**
		 * Este m�todo comprueba si el n�mero es primo
		 * @return devuelve true o false
		 */
		public boolean esPrimo() {
			  // El 0, 1 y 4 no son primos
			  if (num == 0 || num == 1 || num == 4) {
			    return false;
			  }
			  for (int x = 2; x < num / 2; x++) {
			    // Si es divisible por cualquiera de estos n�meros, no
			    // es primo
			    if (num % x == 0)
			      return false;
			  }
			  // Si no se pudo dividir por ninguno de los de arriba, s� es primo
			  return true;
			}		

}

 class E2U9Primo {
	
	public static void main(String[] args) {
	
		Primo x = new Primo(1); //Se crea objeto x de la clase Primo
		
		//Si la funci�n esPrimo devuelve true
		// escribimos el n�mero usando getValue
		if (x.esPrimo())
			System.out.println("ES PRIMO " + x.getValue());
		
		x.setValue(5);
		if (x.esPrimo()) 
			System.out.println("ES PRIMO " + x.getValue()); 
		
		x.setValue(8);
		if (x.esPrimo())
			System.out.println("ES PRIMO " + x.getValue());
		
		x.setValue(11);
		if (x.esPrimo())
			System.out.println("ES PRIMO " + x.getValue());
		
		
	}
	
}

