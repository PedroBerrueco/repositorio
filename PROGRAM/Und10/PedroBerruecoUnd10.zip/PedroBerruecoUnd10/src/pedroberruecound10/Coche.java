package pedroberruecound10;

/**
 * Clase Coche con todos los atributos y m�todos que usar�n los objetos de la
 * clase PruebaCoche.
 * 
 * @author pedroberrueco
 * @version 1.0
 *
 */
public class Coche {

	// ATRIBUTOS DE LA CLASE
	private String modelo;
	private int velocidad;
	private double consumo;
	private double deposito;
	private int kilometros;
	private boolean estado;
	static int fabricados;

	/**
	 * CONSTRUCTOR
	 * 
	 * @param modelo   Ser� el modelo del objeto coche.
	 * @param deposito Litros con los que sale del concesionario.
	 * @param consumo  Consumo del coche (km*l)100
	 */
	public Coche(String modelo, double consumo, double deposito) {
		this.modelo = modelo;
		this.consumo = consumo;
		this.deposito = deposito;
		fabricados++;

	}

	/**
	 * Funci�n ACELERAR incremente el valor del atributo velocidad.
	 * 
	 * @param velocidad Valor entero de Km/h que acelera el coche.
	 */
	public void acelerar(int velocidad) {
		if (estado) {
			int anterior = this.velocidad;
			if ((anterior + velocidad) <= 120) {
				this.velocidad += velocidad;
				System.out.println("Se acelera desde " + anterior + " hasta " + this.velocidad);
			} else {
				System.out.println("Error: Limite m�ximo 120 Km/h");
			}
		} else {
			System.out.println("Coche apagado, funci�n acelerar deshabilitada");
		}
	}

	/**
	 * Funci�n FRENAR decrementa el valor del atributo velocidad.
	 * 
	 * @param velocidad Valor entero de Km/h que frena el coche.
	 */
	public void frenar(int velocidad) {

		if (estado) {
			int anterior = this.velocidad;
			if ((anterior - velocidad) >= 0) {
				this.velocidad -= velocidad;
				System.out.println("Se frena desde " + anterior + " hasta " + this.velocidad);
			} else {
				System.out.println("Error: No puedes frenar por debajo de 0 Km/h");
			}
		} else {
			System.out.println("Coche apagado, funci�n frenar deshabilitada");
		}
	}

	/**
	 * Funcion CONDUCIR muestra los km que se van a recorrer.
	 * 
	 * @param kilometros que se van a recorrer.
	 */
	public void conducir(int kilometros) {
		if (estado) {

			if (deposito - ((consumo / 100) * kilometros) > 0.0 && velocidad > 0) {
				this.kilometros += kilometros;
				double antdep = deposito;
				deposito -= (consumo / 100) * kilometros;
				System.out.println("Has conducido " + kilometros + " Kms");
				System.out.printf("-> El deposito paso de %.2f a %.2f", antdep, deposito);
				System.out.println();
			} else {
				System.out.println("O no tienes suficiente gasolina o no tienes suficiente velocidad para conducir " +kilometros+ " Km");
			}
		} else {
			System.out.println("Coche apagado, funci�n conducir deshabilitada");
		}
	}

	/**
	 * Funci�n REPOSTAR cuando se llena el deposito del coche.
	 * 
	 * @param litros de gasolina que se van a sumar al deposito.
	 */
	public void repostar(double litros) {
		if (!estado) {
			double antdep = deposito;
			deposito += litros;
			System.out.printf("Se reposta de %.2f a %.2f", antdep, deposito);
			System.out.println();
		} else {
			System.out.println("Coche arrancado, funci�n repostar deshabilitada");
		}
	}

	/**
	 * Funcion ARRANCAR pone el coche en marcha Permite usar otros metodos
	 * (acelerar, frenar, conducir)
	 */
	public void arrancar() {
		if (!estado) {
			estado = true;
			System.out.println("Coche arrancado correctamente");
		} else {
			System.out.println("Coche arrancado, funci�n arrancar deshabilitada");
		}
	}

	/**
	 * Funcion PARAR pone el coche en marcha Permite usar otros metodos (repostar)
	 */
	public void parar() {
		if (estado) {
			if (velocidad == 0) {
				estado = false;
				System.out.println("Coche parado correctamente");
			} else {
				System.out.println("No apagues el coche en marcha");
			}
		} else {
			System.out.println("Coche parado, funci�n parar deshabilitada");
		}
	}

	@Override
	public String toString() {
		return "Coche [modelo=" + modelo + ", velocidad=" + velocidad + ", deposito=" + deposito + ", consumo="
				+ consumo + ", kilometraje=" + kilometros + ", arrancado=" + estado + "]";
	}

} // Cierra la clase
