package pedroberruecound10;

public class PruebaCoche {

	public static void main(String[] args) {
		
		//Primer coche
		Coche Coche1 = new Coche("BMW M4 Cabrio",10.2, 40);
		Coche1.arrancar();
		Coche1.acelerar(120);
		Coche1.conducir(150);
		Coche1.frenar(30);
		Coche1.conducir(100);
		Coche1.frenar(90);
		Coche1.parar();
		Coche1.repostar(50.5);
		System.out.println(Coche1.toString());
		System.out.println("-------------------");
		
		//Segundo coche
		Coche Coche2 = new Coche("BMW M135i xDrive",7.4, 30);
		Coche2.parar();
		Coche2.acelerar(100);
		Coche2.frenar(50);
		Coche2.conducir(20);
		Coche2.arrancar();
		Coche2.repostar(10.0);
		Coche2.acelerar(150);
		Coche2.acelerar(100);
		Coche2.parar();
		Coche2.conducir(1000);
		Coche2.conducir(150);
		Coche2.frenar(150);
		Coche2.frenar(100);
		Coche2.parar();
		Coche2.parar();
		Coche1.repostar(22.8);
		System.out.println(Coche1.toString());
		System.out.println("-------------------");
		
		//Total de coches fabricados.
		System.out.println("Se han fabricado "+Coche.fabricados+ " coches.");
	
	
	
	
	
	}
}
