/**
 * 
 * Unidad 8
 * Ejercicio 4 (Referencias cruzadas)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */
package PedroBerruecoUnd8;


import java.util.TreeMap;
import java.util.Scanner;
import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;

public class E4U8ReferenciasCruzadas {
	public static void main(String[] args) {

		// Creamos un objeto Scanner para leer por consola
		Scanner input = new Scanner(System.in);
		// Creamos un TreeMap para almacenar el texto, para que aparezca en orden
		// alfab�tico como el ejemplo.

		TreeMap<String, List<Integer>> texto = new TreeMap<>();
		int linea = 0;

		// Leemos las l�neas de texto hasta encontrar fin
		System.out.println("Introduzca el texto y escriba fin para terminar: ");
		String textoLinea = input.nextLine();
		while (!textoLinea.equals("fin")) {
			linea++;
			// Separamos la l�nea en palabras
			String[] palabras = textoLinea.split(" ");
			// Para cada palabra
			for (String palabra : palabras) {
				// Si la palabra est� en el mapa, a�adimos el n�mero de l�nea
				if (texto.containsKey(palabra)) {
					List<Integer> lineas = texto.get(palabra);
					// Agregamos el n�mero de l�nea si no existe en la lista
					HashSet<Integer> lineasSet = new HashSet<>(lineas);
					if (!lineasSet.contains(linea)) {
						lineas.add(linea);
					}
				}
				// Si no, a�adimos la palabra y el n�mero de l�nea
				else {
					ArrayList<Integer> lineas = new ArrayList<>();
					lineas.add(linea);
					texto.put(palabra, lineas);
				}
			}
			textoLinea = input.nextLine();
		}
		// Imprimimos el resultado
		System.out.println("Referencias cruzadas: ");
		for (String palabra : texto.keySet()) {
			List<Integer> lineas = texto.get(palabra);
			System.out.print(palabra + " ");
			for (int i : lineas) {
				System.out.print(i + " ");
			}
			System.out.println();
		}
	}
}