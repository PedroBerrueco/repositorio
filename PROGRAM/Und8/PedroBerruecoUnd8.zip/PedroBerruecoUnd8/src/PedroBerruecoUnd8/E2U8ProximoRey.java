/**
 * 
 * Unidad 8
 * Ejercicio 2 (Pr�ximo Rey)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */
package PedroBerruecoUnd8;

import java.text.NumberFormat;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Scanner;

public class E2U8ProximoRey {
	
	//Metodo para convertir n�meros enteros en Romanos.
	public static String EnteroARomano(int numero) {
	    String[] unidadesRomanas  = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"};
	    int unidades  = numero % 10;

	    String numeroRomano = "";
	    numeroRomano += unidadesRomanas[unidades];

	    return numeroRomano;
	}

	public static void main(String[] args) {
	
	//INICIO	
		Scanner scanner = new Scanner(System.in);
		//Uso de LinkedHAshMap para mantener el orden de insercci�n de los elementos.
		LinkedHashMap <String, Integer> reyes = new LinkedHashMap<>(); 
		
		System.out.println("Escribe la dinastia en orden cronologico, separado por espacios: ");
		String dinastia = scanner.nextLine();
		
		//Separar en un array cada nombre. 
		String[] nombres = dinastia.split(" ");

	//PROCESO
		for (String nombre : nombres) {
			//Recorro Array, si el nombre existe suma 1 y lo introduce en reyes.
		    if (reyes.containsKey(nombre)) {
		        int contadorActual = reyes.get(nombre);
		        reyes.put(nombre, contadorActual + 1);
		       //En caso de no exixtir previamente introduce el nombre con un 1.
		    } else {
		        reyes.put(nombre, 1);
		    }
		}
		
		//Solicitamos nuevo monarca
		System.out.print("Introduzca un nombre de monarca: ");
		String nuevoMonarca = scanner.nextLine();
	
		//SALIDA
			//Mismo proceso que ante, pero sacando la info por consola. 
		if (reyes.containsKey(nuevoMonarca)) {
			int contadorActual = reyes.get(nuevoMonarca);
			//He agregado este m�todo para hacerlo m�s elegante
			String contadorRomano = EnteroARomano(contadorActual + 1);
			System.out.print("Ser� coronado como " +nuevoMonarca + " " + contadorRomano);
		} else {
		    System.out.print("Ser� coronado como " +nuevoMonarca + " I");
		}
		}
	}


