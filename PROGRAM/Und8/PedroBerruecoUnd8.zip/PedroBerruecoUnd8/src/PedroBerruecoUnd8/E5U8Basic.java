/**
 * 
 * Unidad 8
 * Ejercicio 5 (BASIC)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package PedroBerruecoUnd8;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.TreeMap;

public class E5U8Basic {
	public static void main(String[] args) {

		TreeMap<String, String> map = new TreeMap<>();
		boolean fin = false;
		int seguimos = 0;

		// USUARIO METE VARIAS LINEAS NO HAGO NADA HASTA QUE HAYA INGRESADO fin ENTONCES
		// TERMINO ESTE BUCLE.
		while (seguimos < 1) {
			seguimos = 0;
			System.out.println("Ingrese comandos BASIC linea a linea.");
			System.out.println("'fin' para terminar.");
			// Limpiamos el TreeMap antes de volver al bucle
			map.clear();
			do {
				fin = false;
				Scanner sc = new Scanner(System.in);
				String linea = sc.nextLine();

				// Divide la l�nea en la clave y el valor
				String[] parts = linea.split("\\s+", 2);
				String key = parts[0];
				String value = "";

				// Si se ingres� una l�nea con dos o m�s palabras, se extrae el valor
				if (parts.length > 1) {
					value = parts[1];
				}

				// Guarda la l�nea en el TreeMap
				map.put(key, value);

				// Si el usuario escribe "fin" salimos del bucle.
				if (key.equals("fin")) {
					fin = true;
				}

			} while (!fin);

			// VALIDO QUE
			for (String key : map.keySet()) {
				if ((key.matches("[0-9]+") || key.equals("fin"))) {
					seguimos++;
				} else {
					System.out.println(key + " No se reconoce como n�mero de l�nea. Error.");
					seguimos = -1000000;
				}
			}
		}
		
		// Quitamos el par con key fin
		map.remove("fin");

		// Creamos una lista para guardar los elementos que queremos borrar
		ArrayList<String> elementosABorrar = new ArrayList<>();
		int lineaDestino = 0;
		// Recorremos el map TreeMap
		for (String key : map.keySet()) { 
			// Obtenemos el valor de la clave 
			String value = map.get(key); 
			// Comprobamos si contiene la palabra GOTO
			if (value.contains("GOTO")) { 
				// Si la contiene, guardamos los valores de la linea y la linea destino
				int lineaActual = Integer.parseInt(key);
				if (value.substring(5).matches("[0-9]+")) {
					// Si el valor linea destino es un n�mero, seguimos con el c�digo
					lineaDestino = Integer.parseInt(value.substring(5));
				} else {
					// En caso de que no sea un n�mero, a�adimos la l�nea a la lista para borrar
					elementosABorrar.add(key);
				}
				// Recorremos el map TreeMap
				for (String key2 : map.keySet()) {
					int lineaActual2 = Integer.parseInt(key2);
					// Comprobamos si hay alguna linea entre las dos lineas guardadas
					if (lineaActual2 > lineaActual && lineaActual2 < lineaDestino) {
						// Si hay alguna linea, la a�adimos a la lista para borrar
						elementosABorrar.add(key2);
					}
				}
			}
		}

		// Una vez hayamos terminado de recorrer el map, borramos los elementos de la lista
		for (String key : elementosABorrar) {
			map.remove(key);
		}

		// Recorremos el map TreeMap
		for (String key : map.keySet()) {
			// Obtenemos el valor de la clave
			String value = map.get(key);
			// Comprobamos si contiene la palabra PRINT
			if (value.contains("PRINT")) {
				// Obtenemos el substring a partir del car�cter 6, que es donde empieza la parte de la cadena que queremos imprimir
				String lineaImprimir = value.substring(6);
				// Quitamos las comillas
				lineaImprimir = lineaImprimir.replaceAll("\"", "");
				// Imprimimos la l�nea
				System.out.println(lineaImprimir);
			}
		
		}

	}
}
