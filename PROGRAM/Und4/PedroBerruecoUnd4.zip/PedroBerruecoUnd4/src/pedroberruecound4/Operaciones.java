package pedroberruecound4;

import java.util.Scanner;

public class Operaciones {

	// M�todo para pedir al usuario que introduzca las coordenadas d�nde se hubican
	// los �rboles.
	public static int[][] pidearbol(int[][] camping) {

		Scanner teclado = new Scanner(System.in);
		int fila = 0;
		int colu = 0;

		for (int i = 0; i < 4; i++) {
			System.out.print("Introduzca fila del �rbol " + (i + 1) + ": ");
			fila = teclado.nextInt();
			System.out.print("Introduzca columna del arbol " + (i + 1) + ": ");
			colu = teclado.nextInt();
			// marcamos un 1 en la coordenada seleccionada.
			camping[fila][colu] = 1;

		}
		return camping;

	}

	// M�todo que recorr� el Array y marca un 1 en las casillas alrededor del tronco
	// del arbol.
	public static int[][] dibujasombra(int[][] camping) {

		// Me apoyo en otro array que es el que modifico para no perder la informaci�n
		// original.
		int[][] copiacamp = new int[10][10];

		// No se me ha ocurrido una forma m�s elegante de evitar salirme de los �ndices
		// que controlar TODAS las posibilidades.
		for (int i = 0; i < camping.length; i++) {
			for (int j = 0; j < camping.length; j++) {
				if (camping[i][j] == 1) {
					if ((i > 0) && (i < 9) && ((j > 0) && (j < 9))) { // 1.Sin m�rgenes.
						copiacamp[i - 1][j - 1] = 1;
						copiacamp[i - 1][j] = 1;
						copiacamp[i - 1][j + 1] = 1;
						copiacamp[i][j - 1] = 1;
						copiacamp[i][j] = 1;
						copiacamp[i][j + 1] = 1;
						copiacamp[i + 1][j - 1] = 1;
						copiacamp[i + 1][j] = 1;
						copiacamp[i + 1][j + 1] = 1;
					}
					if ((i == 0) && (j == 0)) { // 2.Esquina superior izquierda.
						copiacamp[i][j] = 1;
						copiacamp[i][j + 1] = 1;
						copiacamp[i + 1][j] = 1;
						copiacamp[i + 1][j + 1] = 1;
					}
					if ((i == 0) && ((j > 0) && (j < 9))) { // 3.Primera fila sin esquinas
						copiacamp[i][j - 1] = 1;
						copiacamp[i][j] = 1;
						copiacamp[i][j + 1] = 1;
						copiacamp[i + 1][j - 1] = 1;
						copiacamp[i + 1][j] = 1;
						copiacamp[i + 1][j + 1] = 1;
					}
					if ((i == 0) && (j == 9)) { // 4.Esquina superior derecha.
						copiacamp[i][j - 1] = 1;
						copiacamp[i][j] = 1;
						copiacamp[i + 1][j - 1] = 1;
						copiacamp[i + 1][j] = 1;
					}
					if (((i > 0) && (i < 9)) && (j == 0)) { // 5.Primera columna sin esquinas
						copiacamp[i - 1][j] = 1;
						copiacamp[i - 1][j + 1] = 1;
						copiacamp[i][j] = 1;
						copiacamp[i][j + 1] = 1;
						copiacamp[i + 1][j] = 1;
						copiacamp[i + 1][j + 1] = 1;
					}
					if (((i > 0) && (i < 9)) && (j == 9)) { // 6.�ltima columna sin esquinas
						copiacamp[i - 1][j - 1] = 1;
						copiacamp[i - 1][j] = 1;
						copiacamp[i][j - 1] = 1;
						copiacamp[i][j] = 1;
						copiacamp[i + 1][j - 1] = 1;
						copiacamp[i + 1][j] = 1;
					}
					if ((i == 9) && (j == 0)) { // 7.Esquina inferior izquierda.
						copiacamp[i - 1][j] = 1;
						copiacamp[i - 1][j + 1] = 1;
						copiacamp[i][j] = 1;
						copiacamp[i][j + 1] = 1;
					}
					if ((i == 9) && ((j > 0) && (j < 9))) { // 8.�ltima fila sin esquinas
						copiacamp[i - 1][j - 1] = 1;
						copiacamp[i - 1][j] = 1;
						copiacamp[i - 1][j + 1] = 1;
						copiacamp[i][j - 1] = 1;
						copiacamp[i][j] = 1;
						copiacamp[i][j + 1] = 1;
					}
					if ((i == 9) && (j == 9)) { // 9.Esquina inferior derecha.
						copiacamp[i - 1][j - 1] = 1;
						copiacamp[i - 1][j] = 1;
						copiacamp[i][j - 1] = 1;
						copiacamp[i][j] = 1;
					}

				}

			}

		}
		return copiacamp;

	}

	// M�todo para recorrer el array con sombras y contar los 1 (parcelas con
	// sombra) que encuentre.
	public static int cuentasombra(int[][] copiacamp) {

		int contador = 0;

		for (int i = 0; i < copiacamp.length; i++) {
			for (int j = 0; j < copiacamp.length; j++) {
				if (copiacamp[i][j] == 1) {
					contador++;
				}

			}
		}

		return contador;
	}
}
