/**
 * 
 * Unidad 4
 * Ejercicio 5 (Camping)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound4;

/* En este ejercicio he querido sacar la nueva clase del fichero java para 
 * dejar todav�a m�s limpio el c�digo que en el ejercicio anterior, as� voy
 *  probando distintas t�cnicas. 
*/

public class E5U4Camping {

	public static void main(String[] args) {

		int[][] camping = new int[10][10];
		int[][] copiacamp = new int[10][10];
		int contador;

		// solicitamos al usuario las coordenadas de los 4 �rboles
		camping = Operaciones.pidearbol(camping);

		// Ponemos las sombras alrededor de los arboles
		copiacamp = Operaciones.dibujasombra(camping);

		// contamos las parcelas en sombra
		contador = Operaciones.cuentasombra(copiacamp);

		System.out.println("La sombra total es: " + contador);
	}

}
