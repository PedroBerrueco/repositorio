/**
 * 
 * Unidad 4
 * Ejercicio 4 (Sudoku)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound4;

import java.util.Scanner;

// Clase creada para dejar m�s limpio el m�todo main
class Ordena {

	// M�todo para ordenar.
	public void ordena(int[][] sudoku) {

		int t = 0; // variable auxiliar
		/*
		 * Recorremos la matriz con 4 for anidados, uno para recorrer todas las filas y
		 * columnas y otro para comparar cada valor de una fila y columna y guardar el
		 * m�s bajo.
		 */
		for (int i = 0; i < sudoku.length; i++) {// Ordena la matriz
			for (int j = 0; j < sudoku[i].length; j++) {
				for (int x = 0; x < 3; x++) {
					for (int y = 0; y < 3; y++) {
						if (sudoku[i][j] < sudoku[x][y]) {
							t = sudoku[i][j];
							sudoku[i][j] = sudoku[x][y];
							sudoku[x][y] = t;
						}
					}
				}
			}
		}
	}

// M�todo para buscar n�meros repetidos.
	public boolean iguales(int[][] sudoku) {
		boolean repetido = false;
		/*
		 * La idea de recorrer la matriz con 4 for anidados me vino de un ejercicio de
		 * la unidad 3 donde orden� y compare un array con dos for anidados, pens� que
		 * si ten�a el doble de datos necesitar�a el doble de for, lo pobr� y funcion�.
		 */
		for (int i = 0; i < sudoku.length; i++) {
			for (int j = 0; j < sudoku[i].length; j++) {
				for (int x = (i); x < 3; x++) {
					for (int y = (j + 1); y < 3; y++) {
						if ((sudoku[i][j]) >= (sudoku[x][y])) {
							repetido = true;
						}

					}

				}
			}
			// M�todo booleano que devuelve el valor true o false de la variable repetido.
		}
		return repetido;
	}
}

public class E4U4Sudoku {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		int sudoku[][] = new int[3][3];
		boolean repe;
		// For anidados para que el usuario introduzca los datos del sudoku.
		for (int i = 0; i < sudoku.length; i++) {
			for (int j = 0; j < sudoku.length; j++) {
				System.out.print("Introduzca los numeros (" + i + "," + j + "): ");
				sudoku[i][j] = teclado.nextInt();
			}
		}

		// M�todo java de ordenaci�n por selecci�n
		Ordena orden = new Ordena();
		orden.ordena(sudoku);

		// M�todo para buscar iguales
		Ordena compara = new Ordena();
		repe = compara.iguales(sudoku);

		// En funci�n del valor que devuelva el m�todo iguales, imprimimos el resultado.
		if (repe == true) {
			System.out.println("Hay repetidos");
		} else {
			System.out.println("NO hay repetidos");
		}

	}

}
