/**
 * 
 * Unidad 4
 * Ejercicio 2 (Buscaminas)
 * 
 * @version 1.0
 * 
 * @author PedroBerrueco
 */

package pedroberruecound4;

import java.util.Scanner;

public class E2U4Buscaminas {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		int nfila = 0;
		int ncolumna = 0;
		int contador = 0;

		// declaramos la matriz y la recorremos con dos for anidados para que el usuario
		// la complete, asumimos que introduce valores correctos.
		String buscaminas[][] = new String[5][5];
		for (int i = 0; i < buscaminas.length; i++) {
			for (int j = 0; j < buscaminas.length; j++) {
				System.out.print("Introduzca coordenadas (" + i + "," + j + "): ");
				buscaminas[i][j] = teclado.nextLine();
			}
		}

		System.out.print("Introduzca la fila a comprobar: ");
		nfila = teclado.nextInt();
		System.out.print("Introduzca la columna a comprobar: ");
		ncolumna = teclado.nextInt();

		//condicion que excluye la columna y fila 0 para evitar salir del �ndice.
		if ((nfila > 0) && (ncolumna > 0)) {
			// Con esos chorizos en las condiciones for lo que le estoy diciendo es que
			// compruebe filas y columnas alrededor pero que no se salga de los indices.
			for (int f = nfila - 1; ((f >= nfila - 1) && (f <= nfila + 1)) && ((f >= 0) && (f <= 4)); f++) {
				for (int c = ncolumna - 1; ((c >= ncolumna - 1) && (c <= ncolumna + 1))
						&& ((c >= 0) && (c <= 4)); c++) {
					//Descarto la propia coordenada que ha marcado el usuario, solo quiero las de alrededor.
					if ((f != nfila) || (c != ncolumna)) {
						if (buscaminas[f][c].equals("*")) {
							contador++;
						}
						/*
						 * System.out.print(f + "" + c); System.out.print(" ");
						 */
					}
				}

			}
		//Condici�n que excluye la columna y fila 4 para evitar salir del �ndice.
		} else if ((nfila < 4) && (ncolumna < 4)) {
			for (int f = nfila + 1; ((f <= nfila + 1) && (f >= nfila - 1)) && ((f >= 0) && (f <= 4)); f--) {
				for (int c = ncolumna + 1; ((c <= ncolumna + 1) && (c >= ncolumna - 1))
						&& ((c >= 0) && (c <= 4)); c--) {
					if ((f != nfila) || (c != ncolumna)) {
						if (buscaminas[f][c].equals("*")) {
							contador++;
						}
					}
				}

			}

		}
		//Imprime el n�mero de veces que haya encontrado asteriscos.
		System.out.println(contador);
	}
}
